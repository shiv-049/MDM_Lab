#include <p18f4550.h>

void main(void)
{
    ADCON1 = 0x0F;       // Digital pins

    TRISAbits.TRISA3 = 1;    // RA3 as input
    TRISDbits.TRISD0 = 0;    // RD0 as output

    while(1)
    {
        if(PORTAbits.RA3 == 1)
        {
            LATDbits.LATD0 = 1;    // LED ON
        }
        else
        {
            LATDbits.LATD0 = 0;    // LED OFF
        }
    }
}
