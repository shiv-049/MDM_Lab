#include <p18f4550.h>

#define ZERO  0x3F
#define TWO   0x5B
#define FOUR  0x66
#define SIX   0x7D
#define EIGHT 0x7F

void delay(unsigned int time)
{
    unsigned int i;

    while(time--)
    {
        for(i = 0; i < 500; i++);
    }
}

void main(void)
{
    ADCON1 = 0x0F;
    TRISB = 0x00;

    while(1)
    {
        LATB = ZERO;
        delay(1000);

        LATB = TWO;
        delay(1000);

        LATB = FOUR;
        delay(1000);

        LATB = SIX;
        delay(1000);

        LATB = EIGHT;
        delay(1000);
    }
}
