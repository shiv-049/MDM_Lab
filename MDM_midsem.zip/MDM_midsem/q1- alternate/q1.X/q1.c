#include <pic18f4550.h>

void delay(int time)
{
    int i;

    for(i = 0; i < time; i++);
}

void main()
{
    TRISB = 0x00;

    while(1)
    {
        // LED1 and LED3 ON, LED2 and LED4 OFF
        LATB = 0x05;
        delay(1000);

        // LED2 and LED4 ON, LED1 and LED3 OFF
        LATB = 0x0A;
        delay(1000);
    }
}
