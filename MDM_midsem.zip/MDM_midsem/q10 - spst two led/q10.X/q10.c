#include <p18f4550.h>

void main(void)
{
    ADCON1 = 0x0F;          // Digital pins

    TRISAbits.TRISA3 = 1;   // Switch input
    TRISDbits.TRISD0 = 0;   // LED1 output
    TRISDbits.TRISD1 = 0;   // LED2 output

    while(1)
    {
        if(PORTAbits.RA3 == 1)
        {
            LATDbits.LATD0 = 1;    // LED1 ON
            LATDbits.LATD1 = 0;    // LED2 OFF
        }
        else
        {
            LATDbits.LATD0 = 0;    // LED1 OFF
            LATDbits.LATD1 = 1;    // LED2 ON
        }
    }
}
