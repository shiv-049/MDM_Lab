#include <p18f4550.h>

void delay(unsigned int time)
{
    unsigned int i;

    while(time--)
    {
        for(i = 0; i < 500; i++);
    }
}

void main(void)
{
    ADCON1 = 0x0F;

    TRISCbits.TRISC1 = 0;

    while(1)
    {
        // Relay ON for 3 seconds
        LATCbits.LATC1 = 1;
        delay(3000);

        // Relay OFF for 3 seconds
        LATCbits.LATC1 = 0;
        delay(3000);
    }
}
