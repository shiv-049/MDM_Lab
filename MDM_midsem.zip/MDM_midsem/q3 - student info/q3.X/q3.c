#include <p18f4550.h>

#define LCD PORTB
#define RS LATDbits.LATD0
#define EN LATDbits.LATD1

void delay(unsigned int t)
{
    unsigned int i,j;

    for(i=0; i<t; i++)
        for(j=0; j<5000; j++);
}

void lcd_cmd(unsigned char cmd)
{
    RS = 0;
    LCD = cmd;
    EN = 1;
    delay(2);
    EN = 0;
}

void lcd_data(unsigned char data)
{
    RS = 1;
    LCD = data;
    EN = 1;
    delay(2);
    EN = 0;
}

void lcd_string(char *str)
{
    while(*str)
        lcd_data(*str++);
}

void main()
{
    ADCON1 = 0x0F;

    TRISB = 0x00;
    TRISD = 0x00;

    delay(20);

    lcd_cmd(0x38);   // 8-bit, 2-line
    lcd_cmd(0x0C);   // Display ON
    lcd_cmd(0x06);   // Cursor increment
    lcd_cmd(0x01);   // Clear LCD

    while(1)
    {
        // Display student information
        lcd_cmd(0x80);              // Line 1
        lcd_string("Mohammed Nouman");

        lcd_cmd(0xC0);              // Line 2
        lcd_string("Roll No: 123");

        delay(200);

        // Blink: turn display OFF
        lcd_cmd(0x08);
        delay(100);

        // Turn display ON
        lcd_cmd(0x0C);
        delay(100);
    }
}
