#include <pic18f4550.h>

void delay(int time)
{
    int i;

    for(i = 0; i < time; i++);
}

void main()
{
    TRISB = 0x00;

    while(1)
    {
        // LED1 to LED4
        LATB = 0x01;
        delay(500);

        LATB = 0x02;
        delay(500);

        LATB = 0x04;
        delay(500);

        LATB = 0x08;
        delay(500);

        // LED4 to LED1
        LATB = 0x04;
        delay(500);

        LATB = 0x02;
        delay(500);

        LATB = 0x01;
        delay(500);
    }
}
