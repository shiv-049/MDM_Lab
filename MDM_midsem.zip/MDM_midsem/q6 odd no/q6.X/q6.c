#include <p18f4550.h>

#define ONE   0x06
#define THREE 0x4F
#define FIVE  0x6D
#define SEVEN 0x07
#define NINE  0x6F

void delay(unsigned int time)
{
    unsigned int i;

    while(time--)
    {
        for(i = 0; i < 500; i++);
    }
}

void main(void)
{
    ADCON1 = 0x0F;
    TRISB = 0x00;

    while(1)
    {
        // Odd digits: 1, 3, 5, 7, 9
        LATB = ONE;
        delay(1000);

        LATB = THREE;
        delay(1000);

        LATB = FIVE;
        delay(1000);

        LATB = SEVEN;
        delay(1000);

        LATB = NINE;
        delay(1000);

        // Reverse: 9, 7, 5, 3, 1
        LATB = NINE;
        delay(1000);

        LATB = SEVEN;
        delay(1000);

        LATB = FIVE;
        delay(1000);

        LATB = THREE;
        delay(1000);

        LATB = ONE;
        delay(1000);
    }
}
