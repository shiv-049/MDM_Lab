#include <p18f4550.h>

#define LCD PORTB
#define RS LATDbits.LATD0
#define EN LATDbits.LATD1

void delay(unsigned int t)
{
    unsigned int i,j;

    for(i=0; i<t; i++)
        for(j=0; j<5000; j++);
}

void lcd_cmd(unsigned char cmd)
{
    RS = 0;
    LCD = cmd;
    EN = 1;
    delay(2);
    EN = 0;
}

void lcd_data(unsigned char data)
{
    RS = 1;
    LCD = data;
    EN = 1;
    delay(2);
    EN = 0;
}

void lcd_string(char *str)
{
    while(*str)
        lcd_data(*str++);
}

void main()
{
    ADCON1 = 0x0F;

    TRISB = 0x00;
    TRISD = 0x00;

    delay(20);

    lcd_cmd(0x38);   // 8-bit, 2-line
    lcd_cmd(0x0C);   // Display ON
    lcd_cmd(0x06);   // Cursor increment
    lcd_cmd(0x01);   // Clear LCD

    while(1)
    {
        // Scroll right to left
        lcd_cmd(0x01);
        lcd_cmd(0x8F);
        lcd_string("MICROCONTROLLER LAB");
        delay(100);

        lcd_cmd(0x01);
        lcd_cmd(0x8E);
        lcd_string("MICROCONTROLLER LAB");
        delay(100);

        lcd_cmd(0x01);
        lcd_cmd(0x8D);
        lcd_string("MICROCONTROLLER LAB");
        delay(100);

        lcd_cmd(0x01);
        lcd_cmd(0x8C);
        lcd_string("MICROCONTROLLER LAB");
        delay(100);

        lcd_cmd(0x01);
        lcd_cmd(0x8B);
        lcd_string("MICROCONTROLLER LAB");
        delay(100);

        lcd_cmd(0x01);
        lcd_cmd(0x8A);
        lcd_string("MICROCONTROLLER LAB");
        delay(100);

        lcd_cmd(0x01);
        lcd_cmd(0x89);
        lcd_string("MICROCONTROLLER LAB");
        delay(100);

        lcd_cmd(0x01);
        lcd_cmd(0x88);
        lcd_string("MICROCONTROLLER LAB");
        delay(100);

        lcd_cmd(0x01);
        lcd_cmd(0x87);
        lcd_string("MICROCONTROLLER LAB");
        delay(100);

        lcd_cmd(0x01);
        lcd_cmd(0x86);
        lcd_string("MICROCONTROLLER LAB");
        delay(100);

        // Scroll left to right
        lcd_cmd(0x01);
        lcd_cmd(0x80);
        lcd_string("MICROCONTROLLER LAB");
        delay(100);

        lcd_cmd(0x01);
        lcd_cmd(0x81);
        lcd_string("MICROCONTROLLER LAB");
        delay(100);

        lcd_cmd(0x01);
        lcd_cmd(0x82);
        lcd_string("MICROCONTROLLER LAB");
        delay(100);

        lcd_cmd(0x01);
        lcd_cmd(0x83);
        lcd_string("MICROCONTROLLER LAB");
        delay(100);

        lcd_cmd(0x01);
        lcd_cmd(0x84);
        lcd_string("MICROCONTROLLER LAB");
        delay(100);

        lcd_cmd(0x01);
        lcd_cmd(0x85);
        lcd_string("MICROCONTROLLER LAB");
        delay(100);

        lcd_cmd(0x01);
        lcd_cmd(0x86);
        lcd_string("MICROCONTROLLER LAB");
        delay(100);

        lcd_cmd(0x01);
        lcd_cmd(0x87);
        lcd_string("MICROCONTROLLER LAB");
        delay(100);

        lcd_cmd(0x01);
        lcd_cmd(0x88);
        lcd_string("MICROCONTROLLER LAB");
        delay(100);

        lcd_cmd(0x01);
        lcd_cmd(0x89);
        lcd_string("MICROCONTROLLER LAB");
        delay(100);

        lcd_cmd(0x01);
        lcd_cmd(0x8A);
        lcd_string("MICROCONTROLLER LAB");
        delay(100);
    }
}
